// Frontend JS for Anak Emak Server Vote
async function fetchJSON(url, opts){ const r = await fetch(url, opts); return r.json().catch(()=>({})); }

async function listServers(){
  const res = await fetch('/api/servers');
  const servers = await res.json();
  const statsR = await fetch('/api/stats');
  const stats = await statsR.json();
  const container = document.getElementById('servers');
  if(!container) return;
  container.innerHTML = '';
  servers.forEach(s=>{
    const c = document.createElement('div');
    c.className = 'prod';
    const votes = stats[s.id] || 0;
    const banner = s.banner ? s.banner : '';
    c.innerHTML = `
      <div class="banner">${ banner ? `<img src="${banner.replace('/public/','')}" alt="">` : '' }</div>
      <div class="pname">${s.name}</div>
      <div class="desc">${s.description}</div>
      <div class="vote-row">
        <button class="btn" data-id="${s.id}">Vote</button>
        <div class="count" id="cnt-${s.id}">${votes} votes</div>
        <a class="btn" href="server.html?id=${s.id}">Detail</a>
      </div>`;
    container.appendChild(c);
  });

  document.querySelectorAll('.btn[data-id]').forEach(b=>{
    b.addEventListener('click', async (ev)=>{
      const id = b.dataset.id;
      b.disabled = true; b.textContent = 'Voting...';
      const resp = await fetch('/api/vote', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({server_id: id}) });
      const data = await resp.json();
      if (resp.ok){ // update counts
        const r = await fetch('/api/stats'); const ns = await r.json();
        document.getElementById(`cnt-${id}`).textContent = `${ns[id]||0} votes`;
        b.textContent = 'Voted ✓';
      } else {
        alert(data.error || 'Gagal vote');
        b.textContent = 'Vote';
      }
      setTimeout(()=>{ b.disabled=false; b.textContent='Vote'; }, 2500);
    });
  });
}

// detail page
async function loadDetail(){
  const qs = new URLSearchParams(location.search);
  const id = qs.get('id');
  if (!id) return;
  const res = await fetch('/api/server/' + encodeURIComponent(id));
  const s = await res.json();
  const container = document.getElementById('detail');
  if (!container) return;
  container.innerHTML = `
    <div class="banner">${ s.banner ? `<img src="${s.banner.replace('/public/','')}" alt="">` : '' }</div>
    <div class="detail-card">
      <h2>${s.name}</h2>
      <p class="desc">${s.description}</p>
      <p><b>IP:</b> ${s.ip || '-'}</p>
      <div class="vote-row">
        <button id="voteBtn" class="btn">Vote</button>
        <div id="voteCount" class="count">${s.votes||0} votes</div>
      </div>
    </div>
  `;
  document.getElementById('voteBtn').addEventListener('click', async ()=>{
    const b = document.getElementById('voteBtn');
    b.disabled = true; b.textContent = 'Voting...';
    const resp = await fetch('/api/vote', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({server_id: id}) });
    const data = await resp.json();
    if (resp.ok){
      const r = await fetch('/api/server/' + encodeURIComponent(id));
      const s2 = await r.json();
      document.getElementById('voteCount').textContent = `${s2.votes||0} votes`;
      b.textContent = 'Voted ✓';
    } else {
      alert(data.error || 'Gagal vote');
      b.textContent = 'Vote';
    }
    setTimeout(()=>{ b.disabled=false; b.textContent='Vote'; }, 2500);
  });
}

// admin logic
async function adminInit(){
  const loginForm = document.getElementById('loginForm');
  const adminActions = document.getElementById('adminActions');
  const votesList = document.getElementById('votesList');
  if (loginForm){
    loginForm.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const fd = new FormData(loginForm);
      const body = { username: fd.get('username'), password: fd.get('password') };
      const r = await fetch('/api/admin/login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
      const j = await r.json();
      if (r.ok){ loginForm.style.display='none'; adminActions.style.display='block'; loadVotes(); } else { alert(j.error||'Gagal login'); }
    });
  }
  const addServer = document.getElementById('addServer');
  if (addServer){
    addServer.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const fd = new FormData(addServer);
      const resp = await fetch('/api/admin/server', { method:'POST', body: fd });
      const j = await resp.json();
      if (resp.ok){ alert('Server ditambahkan'); addServer.reset(); } else { alert(j.error||'Gagal'); }
    });
  }

  async function loadVotes(){
    const r = await fetch('/api/admin/votes');
    const j = await r.json();
    if (Array.isArray(j)){
      votesList.innerHTML = j.map(v=>`<div>${v.server_id} — ${new Date(v.ts).toLocaleString()} — ${v.ip}</div>`).join('');
    } else {
      votesList.innerHTML = 'Tidak tersedia (login diperlukan)';
    }
  }
}

document.addEventListener('DOMContentLoaded', ()=>{
  if (document.getElementById('servers')) {
    listServers();
    document.getElementById('search').addEventListener('input', (e)=>{
      const q = e.target.value.toLowerCase();
      document.querySelectorAll('.prod').forEach(p=>{
        const txt = p.innerText.toLowerCase();
        p.style.display = txt.includes(q) ? '' : 'none';
      });
    });
    document.getElementById('sort').addEventListener('change', (e)=>{
      // simple reload (server-side sort not implemented)
      listServers();
    });
    setInterval(()=>{ fetch('/api/stats').then(r=>r.json()).then(s=>{
      Object.keys(s).forEach(k=>{
        const el = document.getElementById('cnt-'+k);
        if (el) el.textContent = `${s[k]} votes`;
      });
    }) }, 10000);
  }
  if (document.getElementById('detail')) loadDetail();
  adminInit();
});