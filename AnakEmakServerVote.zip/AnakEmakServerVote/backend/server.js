// Simple Node.js + Express backend for Anak Emak Server Vote (MVP B-features)
// Dependencies: express, sqlite3, express-rate-limit, multer, bcryptjs, express-session, helmet
const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const helmet = require('helmet');
const fs = require('fs');

const PORT = process.env.PORT || 3000;
const DBPATH = path.join(__dirname, 'db.sqlite');
const uploadDir = path.join(__dirname, '..', 'frontend', 'public', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const app = express();
app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: process.env.SESSION_SECRET || 'anakemak-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24*3600*1000 }
}));

// Serve frontend static
app.use('/', express.static(path.join(__dirname, '..', 'frontend')));

// File uploads (for admin)
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const safe = Date.now() + '-' + file.originalname.replace(/\s+/g,'-');
    cb(null, safe);
  }
});
const upload = multer({ storage });

// init db
const db = new sqlite3.Database(DBPATH);
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT)`);
  db.run(`CREATE TABLE IF NOT EXISTS servers (id TEXT PRIMARY KEY, name TEXT, description TEXT, banner TEXT, ip TEXT, created_at INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS votes (id INTEGER PRIMARY KEY AUTOINCREMENT, server_id TEXT, ip TEXT, ts INTEGER)`);
});

// seed admin and sample servers
db.get("SELECT COUNT(*) AS c FROM users", (e,row) => {
  if (!e && row.c === 0) {
    const passHash = bcrypt.hashSync('adminpass', 8);
    db.run("INSERT INTO users (username,password,role) VALUES (?,?,?)", ['admin', passHash, 'admin']);
    console.log('Seeded admin /admin:adminpass');
  }
});
db.get("SELECT COUNT(*) AS c FROM servers", (e,row) => {
  if (!e && row.c === 0) {
    const now = Date.now();
    const stm = db.prepare("INSERT INTO servers (id,name,description,banner,ip,created_at) VALUES (?,?,?,?,?,?)");
    stm.run('srv-alpha','Server Alpha - Survival & Mini-games','Server Indonesia friendly for casual players','/public/uploads/sample-alpha.jpg','play.alpha.example', now);
    stm.run('srv-beta','Server Beta - PvP & Events','Komunitas PvP aktif, event mingguan','/public/uploads/sample-beta.jpg','play.beta.example', now);
    stm.finalize();
    // create placeholder sample images
    const sample = path.join(uploadDir, 'sample-alpha.jpg');
    const sample2 = path.join(uploadDir, 'sample-beta.jpg');
    if (!fs.existsSync(sample)) fs.writeFileSync(sample, '');
    if (!fs.existsSync(sample2)) fs.writeFileSync(sample2, '');
    console.log('Seeded sample servers');
  }
});

// simple rate limiter for API (global)
const apiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 300
});
app.use('/api/', apiLimiter);

// helper to check cooldown: 6 hours per IP per server
function canVote(ip, server_id, cb) {
  const WINDOW = 6 * 3600 * 1000;
  const since = Date.now() - WINDOW;
  db.get("SELECT COUNT(*) AS c FROM votes WHERE ip = ? AND server_id = ? AND ts > ?", [ip, server_id, since], (err,row) => {
    if (err) return cb(err);
    cb(null, row.c === 0);
  });
}

// API: list servers
app.get('/api/servers', (req,res) => {
  db.all("SELECT id,name,description,banner,ip,created_at FROM servers ORDER BY created_at DESC", [], (err, rows) => {
    if (err) return res.status(500).json({error:'db'});
    res.json(rows);
  });
});

// API: server detail + stats
app.get('/api/server/:id', (req,res) => {
  const id = req.params.id;
  db.get("SELECT id,name,description,banner,ip,created_at FROM servers WHERE id = ?", [id], (err,row) => {
    if (err) return res.status(500).json({error:'db'});
    if (!row) return res.status(404).json({error:'not found'});
    db.get("SELECT COUNT(*) AS c FROM votes WHERE server_id = ?", [id], (e2, rv) => {
      row.votes = rv ? rv.c : 0;
      res.json(row);
    });
  });
});

// API: stats all servers
app.get('/api/stats', (req,res) => {
  db.all("SELECT server_id, COUNT(*) AS c FROM votes GROUP BY server_id", [], (err, rows) => {
    if (err) return res.status(500).json({error:'db'});
    const out = {};
    rows.forEach(r => out[r.server_id] = r.c);
    res.json(out);
  });
});

// API: vote
app.post('/api/vote', (req,res) => {
  const server_id = req.body.server_id;
  if (!server_id) return res.status(400).json({error:'server_id required'});
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  db.get("SELECT id FROM servers WHERE id = ?", [server_id], (err, srow) => {
    if (err) return res.status(500).json({error:'db'});
    if (!srow) return res.status(404).json({error:'server not found'});

    canVote(ip, server_id, (e, allowed) => {
      if (e) return res.status(500).json({error:'db'});
      if (!allowed) return res.status(429).json({error:'cooldown'});
      const ts = Date.now();
      db.run("INSERT INTO votes (server_id, ip, ts) VALUES (?,?,?)", [server_id, ip, ts], function(err2) {
        if (err2) return res.status(500).json({error:'db insert'});
        res.json({ok:true, message:'voted'});
      });
    });
  });
});

// Admin login (simple session)
app.post('/api/admin/login', (req,res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({error:'missing'});
  db.get("SELECT id,username,password,role FROM users WHERE username = ?", [username], (err,row) => {
    if (err) return res.status(500).json({error:'db'});
    if (!row) return res.status(401).json({error:'invalid'});
    if (!bcrypt.compareSync(password, row.password)) return res.status(401).json({error:'invalid'});
    req.session.user = { id: row.id, username: row.username, role: row.role };
    res.json({ok:true});
  });
});

function requireAdmin(req,res,next){
  if (req.session && req.session.user && req.session.user.role === 'admin') return next();
  return res.status(403).json({error:'forbidden'});
}

// Admin: add server
app.post('/api/admin/server', requireAdmin, upload.single('banner'), (req,res) => {
  const { id, name, description, ip } = req.body;
  if (!id || !name) return res.status(400).json({error:'missing'});
  const banner = req.file ? '/public/uploads/' + req.file.filename : '';
  const now = Date.now();
  db.run("INSERT INTO servers (id,name,description,banner,ip,created_at) VALUES (?,?,?,?,?,?)", [id, name, description || '', banner, ip || '', now], function(err){
    if (err) return res.status(500).json({error:'db insert'});
    res.json({ok:true});
  });
});

// Admin: list votes (simple)
app.get('/api/admin/votes', requireAdmin, (req,res) => {
  db.all("SELECT id,server_id,ip,ts FROM votes ORDER BY ts DESC LIMIT 500", [], (err, rows) => {
    if (err) return res.status(500).json({error:'db'});
    res.json(rows);
  });
});

app.listen(PORT, () => {
  console.log('Server listening on', PORT);
});